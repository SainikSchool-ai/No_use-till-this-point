# SainikSchool AI — Login and automatic app updates setup

This change connects the Android sign-in screen to the shared Cloudflare API and changes the updater to download through the API Worker. The source GitHub repository can remain private: the APK is copied to a private Cloudflare R2 bucket and streamed by the Worker. The Minecraft Worker `sainikschool-panel` and root `index.html` are not replaced.

## A. Configure the Cloudflare API

1. In Cloudflare Dashboard, open **Workers & Pages → D1 SQL Database → Create database**. Name it exactly `SAINIKSCHOOL_DB`.
2. Copy its database ID. Open `workers/sainikschool-api/wrangler.jsonc` and replace `REPLACE_WITH_D1_DATABASE_ID` with that ID. Commit the change.
3. Open the new D1 database's **Console** and run the complete SQL from `workers/sainikschool-api/migrations/0001_initial.sql` once.
4. Open **R2 Object Storage → Create bucket**. Name it exactly `sainikschool-app-updates`. Keep the bucket private; do not enable public bucket access.
5. Create the new Worker named `sainikschool-api` from the same private GitHub repository. Set its root directory to `workers/sainikschool-api`, install/build command to `npm install`, and deploy command to `npm run deploy`. Do not edit or replace the existing `sainikschool-panel` Worker.
6. The Worker config already binds D1 as `DB` and R2 as `UPDATES_BUCKET`. Check that both bindings appear in the Worker settings after deployment.
7. In the new Worker, open **Settings → Variables and Secrets** and add `BOOTSTRAP_OWNER_SECRET` as a Secret. Use a long random value (at least 32 characters). Never put it in Android, website JavaScript, or a committed file.
8. Set `ALLOWED_ORIGINS` to the exact published SainikSchool AI website origin. The current starter value is `https://sainikschool-ai.pages.dev`; change it if your Pages URL is different.
9. Check the API by opening:
   `https://sainikschool-api.minecraft-server-panel.workers.dev/api/v1/health`
   It should return JSON with `"ok":true`. The current Android and website config assumes the account's workers.dev subdomain is `minecraft-server-panel`, based on the existing Minecraft Worker URL. If Cloudflare shows a different URL, change `BASE_URL` in `Android/app/src/main/java/com/rakshapal/library/SainikSchoolApi.kt` and `apiBaseUrl` in `web/sainikschool-ai/config.js` to the exact URL.

## B. Create the Root/Owner Admin once

After the Worker is deployed and its secret is set, run this from a terminal. Replace the three example values locally; do not send the password or secret in chat:

```bash
curl -X POST "https://sainikschool-api.minecraft-server-panel.workers.dev/api/v1/auth/bootstrap-owner" \
  -H "Authorization: Bearer YOUR_BOOTSTRAP_OWNER_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"username":"YOUR_OWNER_USERNAME","password":"YOUR_LONG_OWNER_PASSWORD"}'
```

A successful response has HTTP status `201`. Save the owner credentials securely. Then remove/rotate `BOOTSTRAP_OWNER_SECRET` in Worker settings. The endpoint is one-time and refuses to create a second owner.

## C. Configure private APK distribution for auto-update

The app must not contain a GitHub token. Because the source repository is private, the Android updater now uses the Cloudflare Worker and private R2 bucket instead of downloading a GitHub release anonymously.

1. In Cloudflare, create an **R2 API token** with Object Read & Write access restricted to the `sainikschool-app-updates` bucket. Create its Access Key ID and Secret Access Key.
2. In GitHub repository **Settings → Secrets and variables → Actions**, add these repository secrets:
   - `CLOUDFLARE_ACCOUNT_ID`
   - `R2_ACCESS_KEY_ID`
   - `R2_SECRET_ACCESS_KEY`
3. Push the updated project to the `main` branch and wait for the **Build SainikSchool AI** workflow to finish successfully.
4. Open **Actions → Publish SainikSchool AI → Run workflow**. Enter a new tag such as `v1.0.1` (each tag must be unique).
5. The publish workflow keeps the GitHub Release and also uploads `app.apk` plus `latest.json` to the private R2 bucket. The Android app reads `/updates/latest` and downloads `/updates/app.apk` through the Worker.
6. Test these endpoints after publishing:
   - `https://sainikschool-api.minecraft-server-panel.workers.dev/updates/latest` should return release metadata JSON.
   - `https://sainikschool-api.minecraft-server-panel.workers.dev/updates/app.apk` should download the APK.

## D. Build and test Android

1. Wait for the GitHub **Build SainikSchool AI** workflow to finish after the code changes are pushed.
2. Download/install the newly built APK using your existing signed release process.
3. Sign in using the Root/Owner Admin credentials created in section B.
4. The Android client sends `X-Client-Platform: android`, receives a bearer session token, and stores it encrypted using Android Keystore. A valid session is restored when the app is reopened. Sign out revokes the server session.
5. Other accounts are created by the Root/Owner Admin; self-registration is intentionally not enabled. Users without a connected email see the persistent **Connect an email** notice.

## What the update icon does

The small bell at the top-right of the login and signed-in screens is intentionally subtle. No badge means no known update. Amber means an update was found/downloading; the small label shows download percentage. Green means the APK is ready. Download begins automatically without asking the user. After download, the app opens the install dialog; Android still requires the user to confirm installation in its system installer.

## Important limits

- The app cannot complete Cloudflare setup or create your owner account until you perform sections A and B.
- Automatic update distribution cannot work until the R2 bucket and GitHub Actions secrets are configured and at least one release is published.
- Google email connection and password-reset workflows are not part of this login API yet. The login screen now explains that account creation is owner-controlled and directs password-reset requests to the Owner Admin instead of displaying false “next milestone” promises.
- I could not run a full Android Gradle build in this environment because the Gradle distribution could not be downloaded. XML files were parsed successfully and the edited Kotlin files passed a syntax-only check, but the GitHub Actions build must be used for the real Android compilation test.
