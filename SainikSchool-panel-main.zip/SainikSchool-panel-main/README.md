# SainikSchool-panel
This is a better panel for everyone to join this sainik school server
