# SainikSchool AI Phase 2 architecture

This repository now has a proposed separate web frontend and API Worker scaffold:

- `Android/` — existing Android application; unchanged.
- `index.html` — existing Minecraft panel entry page; unchanged.
- `web/sainikschool-ai/` — new browser login/dashboard starter.
- `workers/sainikschool-api/` — new shared authentication API Worker starter.
- `workers/minecraft-panel/` — reserved for a future move only if the current Cloudflare deployment source is identified. No existing Minecraft files were moved.

The API uses D1 for accounts, sessions, and audit records. The existing Minecraft whitelist storage is intentionally not reused for school accounts.

Read `workers/sainikschool-api/README.md` before configuring or deploying. This scaffold is not yet a production deployment. The API requires a D1 database, a real database ID, a strong bootstrap secret, exact CORS origins, rate limiting, and security review. The Android login UI is intentionally unchanged; Android API integration is the next implementation step after the API is deployed and tested.
