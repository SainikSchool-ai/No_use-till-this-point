# SainikSchool AI API (Phase 2 starter)

This is a new, separate Worker. It does not replace `sainikschool-panel` or the repository-root `index.html`.

## Before deployment
1. Create a Cloudflare D1 database named `SAINIKSCHOOL_DB`.
2. Put its actual database ID into `wrangler.jsonc`.
3. Set `ALLOWED_ORIGINS` to the exact deployed web-app origin(s), comma-separated.
4. Add the secret `BOOTSTRAP_OWNER_SECRET` using `wrangler secret put BOOTSTRAP_OWNER_SECRET`.
5. Install dependencies and apply migrations:
   - `npm install`
   - `npm run db:remote`
6. Deploy with `npm run deploy`.
7. Set the deployed Worker URL in `web/sainikschool-ai/config.js`.

## Initialize the owner once
Call `POST /api/v1/auth/bootstrap-owner` with:
- `Authorization: Bearer <BOOTSTRAP_OWNER_SECRET>`
- JSON body: `{"username":"your-owner-username","password":"a-long-unique-password"}`

The endpoint refuses to create another owner once an owner exists. Do not put the bootstrap secret in the web app, Android app, GitHub frontend secrets, or source code. After successful initialization, rotate/remove the bootstrap secret in Cloudflare.

## Endpoints in this starter
- `GET /api/v1/health`
- `POST /api/v1/auth/bootstrap-owner` (one-time, secret-protected)
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/logout`
- `POST /api/v1/admin/users` (owner only; creates admin/user accounts)

Browser login uses a Secure, HttpOnly, SameSite=Lax cookie. Android login can send `X-Client-Platform: android`; the API then returns an access token for secure native storage. The Android app has intentionally not been modified in this starter.

## Important limitations before production
- Configure exact production origins; do not use wildcard CORS.
- Add rate limiting / Turnstile protection before exposing login publicly.
- Add email connection and Google OAuth flows only after configuring the Google OAuth client and callback URLs.
- Add password reset with single-use, expiring tokens and email delivery.
- Add session revocation and account-management endpoints before general release.
- Configure backups and test D1 restore.
- Review the API security and run integration tests before production use.
