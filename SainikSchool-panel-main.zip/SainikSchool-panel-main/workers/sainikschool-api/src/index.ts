interface Env {
  DB: D1Database;
  BOOTSTRAP_OWNER_SECRET: string;
  ALLOWED_ORIGINS: string;
}
type UserRow = {
  id: string; username: string; email: string | null; role: "owner"|"admin"|"user";
  email_connected: number; is_active: number;
};
const SESSION_SECONDS = 60 * 60 * 24 * 14;
const encoder = new TextEncoder();

function json(data: unknown, status = 200, headers: HeadersInit = {}) {
  return new Response(JSON.stringify(data), {
    status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers }
  });
}
function allowedOrigin(request: Request, env: Env) {
  const origin = request.headers.get("Origin");
  const allowed = (env.ALLOWED_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean);
  return !!origin && allowed.includes(origin);
}
function corsHeaders(request: Request, env: Env): HeadersInit {
  const origin = request.headers.get("Origin");
  if (!origin || !allowedOrigin(request, env)) return {};
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Platform",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Vary": "Origin"
  };
}
function cookieToken(request: Request) {
  const raw = request.headers.get("Cookie") || "";
  const match = raw.match(/(?:^|;\\s*)ssai_session=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}
function bearerToken(request: Request) {
  const header = request.headers.get("Authorization") || "";
  return header.startsWith("Bearer ") ? header.slice(7) : null;
}
async function sha256(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function randomToken(bytes = 32) {
  const data = crypto.getRandomValues(new Uint8Array(bytes));
  return btoa(String.fromCharCode(...data)).replace(/\\+/g, "-").replace(/\\//g, "_").replace(/=+$/g, "");
}
async function hashPassword(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: encoder.encode(salt), iterations: 310000, hash: "SHA-256" }, key, 256
  );
  return [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function safeUser(row: UserRow) {
  return { id: row.id, username: row.username, email: row.email, role: row.role, emailConnected: !!row.email_connected };
}
async function currentUser(request: Request, env: Env) {
  const token = bearerToken(request) || cookieToken(request);
  if (!token) return null;
  const tokenHash = await sha256(token);
  const row = await env.DB.prepare(
    `SELECT u.id,u.username,u.email,u.role,u.email_connected,u.is_active
     FROM sessions s JOIN users u ON u.id=s.user_id
     WHERE s.token_hash=? AND s.expires_at>? AND u.is_active=1`
  ).bind(tokenHash, Math.floor(Date.now()/1000)).first<UserRow>();
  return row || null;
}
async function createSession(user: UserRow, request: Request, env: Env) {
  const token = randomToken();
  const expires = Math.floor(Date.now()/1000) + SESSION_SECONDS;
  await env.DB.prepare("INSERT INTO sessions (id,user_id,token_hash,expires_at) VALUES (?,?,?,?)")
    .bind(crypto.randomUUID(), user.id, await sha256(token), expires).run();
  const isAndroid = request.headers.get("X-Client-Platform") === "android";
  const cookie = `ssai_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${SESSION_SECONDS}`;
  return { token, cookie, isAndroid };
}
async function route(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  if (request.method === "GET" && path === "/api/v1/health") return json({ ok: true, service: "sainikschool-api", version: 1 });
  if (request.method === "POST" && path === "/api/v1/auth/bootstrap-owner") {
    if (!env.BOOTSTRAP_OWNER_SECRET) return json({ error: "Owner bootstrap is not configured." }, 503);
    const supplied = request.headers.get("Authorization")?.replace(/^Bearer /, "") || "";
    if (supplied.length < 20 || supplied !== env.BOOTSTRAP_OWNER_SECRET) return json({ error: "Unauthorized." }, 401);
    const existing = await env.DB.prepare("SELECT id FROM users WHERE role='owner' LIMIT 1").first();
    if (existing) return json({ error: "Owner account has already been initialized." }, 409);
    const body = await request.json() as { username?: string; password?: string };
    const username = (body.username || "").trim();
    const password = body.password || "";
    if (!/^[A-Za-z0-9_.-]{3,32}$/.test(username) || password.length < 12) {
      return json({ error: "Username must be 3–32 characters; owner password must be at least 12 characters." }, 400);
    }
    const salt = randomToken(16);
    const id = crypto.randomUUID();
    await env.DB.prepare(
      "INSERT INTO users (id,username,password_hash,password_salt,role,email_connected,email_verified) VALUES (?,?,?,?, 'owner',1,1)"
    ).bind(id, username, await hashPassword(password, salt), salt).run();
    await env.DB.prepare("INSERT INTO audit_logs (id,action,target_user_id) VALUES (?,?,?)")
      .bind(crypto.randomUUID(), "owner.bootstrap", id).run();
    return json({ ok: true, message: "Owner account initialized. Store the credentials securely." }, 201);
  }
  if (request.method === "POST" && path === "/api/v1/auth/login") {
    if (request.headers.get("Origin") && !allowedOrigin(request, env)) return json({ error: "Origin not allowed." }, 403);
    const body = await request.json() as { identifier?: string; password?: string };
    const identifier = (body.identifier || "").trim();
    const password = body.password || "";
    if (!identifier || !password) return json({ error: "Enter username/email and password." }, 400);
    const row = await env.DB.prepare(
      "SELECT id,username,email,password_hash,password_salt,role,email_connected,is_active FROM users WHERE username=? COLLATE NOCASE OR email=? COLLATE NOCASE LIMIT 1"
    ).bind(identifier, identifier).first<UserRow & {password_hash:string;password_salt:string}>();
    if (!row || !row.is_active) return json({ error: "Invalid username/email or password." }, 401);
    const candidate = await hashPassword(password, row.password_salt);
    if (candidate !== row.password_hash) return json({ error: "Invalid username/email or password." }, 401);
    const session = await createSession(row, request, env);
    const headers: HeadersInit = { "Set-Cookie": session.cookie, ...corsHeaders(request, env) };
    return json({ ok: true, user: safeUser(row), ...(session.isAndroid ? { accessToken: session.token, expiresIn: SESSION_SECONDS } : {}) }, 200, headers);
  }
  if (request.method === "GET" && path === "/api/v1/auth/me") {
    const user = await currentUser(request, env);
    return user ? json({ user: safeUser(user) }, 200, corsHeaders(request, env)) : json({ error: "Not authenticated." }, 401, corsHeaders(request, env));
  }
  if (request.method === "POST" && path === "/api/v1/auth/logout") {
    const token = bearerToken(request) || cookieToken(request);
    if (token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(token)).run();
    return json({ ok: true }, 200, { ...corsHeaders(request, env), "Set-Cookie": "ssai_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0" });
  }
  if (request.method === "POST" && path === "/api/v1/admin/users") {
    const actor = await currentUser(request, env);
    if (!actor || actor.role !== "owner") return json({ error: "Owner permission required." }, 403, corsHeaders(request, env));
    const body = await request.json() as { username?:string; email?:string; password?:string; role?:string };
    const username = (body.username || "").trim();
    const email = (body.email || "").trim().toLowerCase() || null;
    const password = body.password || "";
    const role = body.role || "user";
    if (!/^[A-Za-z0-9_.-]{3,32}$/.test(username) || password.length < 12 || !["admin","user"].includes(role)) {
      return json({ error: "Provide a valid username, a password of at least 12 characters, and role admin or user." }, 400, corsHeaders(request, env));
    }
    const salt = randomToken(16);
    const id = crypto.randomUUID();
    try {
      await env.DB.prepare(
        "INSERT INTO users (id,username,email,password_hash,password_salt,role,email_connected,email_verified) VALUES (?,?,?,?,?,?,0,0)"
      ).bind(id, username, email, await hashPassword(password, salt), salt, role).run();
    } catch (_) { return json({ error: "Username or email is already in use." }, 409, corsHeaders(request, env)); }
    await env.DB.prepare("INSERT INTO audit_logs (id,actor_user_id,action,target_user_id) VALUES (?,?,?,?)")
      .bind(crypto.randomUUID(), actor.id, "user.create", id).run();
    return json({ ok: true, user: { id, username, email, role, emailConnected: false } }, 201, corsHeaders(request, env));
  }
  return json({ error: "Not found." }, 404, corsHeaders(request, env));
}
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(request, env) });
    try { return await route(request, env); }
    catch (error) {
      console.error("API error", error);
      return json({ error: "Internal server error." }, 500, corsHeaders(request, env));
    }
  }
};
