# SainikSchool AI Updates Worker

This is a separate Cloudflare Worker for Android app updates. It does not replace or modify `workers/sainikschool-api` or the Minecraft `sainikschool-panel` Worker. It uses GitHub Releases as the APK store; it does not require R2, D1, KV, or a Cloudflare payment method.

## Deploy from Android Termux

Install Termux, then run:

```sh
pkg update -y
pkg install nodejs-lts -y
```

Download the repository ZIP from GitHub (or copy this folder into Termux storage), then enter this folder:

```sh
cd workers/sainikschool-updates
npm install
npx wrangler login
```

Create a GitHub fine-grained personal access token for resource owner `SainikSchool-ai`, limited to repository `SainikSchool-panel`, with **Contents: Read-only** and Metadata read access. Do not paste the token into source code or commit it.

Store it securely as a Worker secret:

```sh
npx wrangler secret put GITHUB_RELEASES_TOKEN
```

Paste the token only into the hidden prompt. Then deploy:

```sh
npx wrangler deploy
```

The expected Worker URL, based on the existing account subdomain, is:

`https://sainikschool-updates.minecraft-server-panel.workers.dev`

Confirm the actual URL printed by Wrangler. If it differs, change `UPDATE_API_BASE_URL` in `Android/app/src/main/java/com/rakshapal/library/UpdateChecker.kt` and rebuild the app.

## Routes

- `GET /health` — Worker health check.
- `GET /api/v1/update/latest` — latest version metadata.
- `GET /api/v1/update/apk` — streams the APK from the private GitHub Release.

## Release requirements

Run the updated `Build SainikSchool AI` workflow first. It creates an artifact containing `app-release.apk` and `update-info.json`. Then run `Publish SainikSchool AI`; the release must contain both `app-debug.apk` and `update-info.json`.

Metadata format:

```json
{
  "versionName": "1.0.123",
  "versionCode": 123,
  "applicationId": "com.sainikschool.ai"
}
```

The build workflow generates these version values from `github.run_number`, matching `Android/app/build.gradle`.

## Security

The GitHub token is stored only as the Cloudflare Worker secret `GITHUB_RELEASES_TOKEN`. It is never included in the Android APK or repository files. Anyone who knows the public Worker URL can download the published APK; the gateway protects the private GitHub repository credentials, not the APK itself.
