interface Env {
  GITHUB_RELEASES_TOKEN: string;
  GITHUB_REPOSITORY: string;
}

interface GitHubAsset {
  id: number;
  name: string;
  size: number;
  url: string;
}

interface GitHubRelease {
  tag_name: string;
  html_url: string;
  assets: GitHubAsset[];
}

interface UpdateInfo {
  versionName: string;
  versionCode: number;
  applicationId: string;
}

const GITHUB_API_VERSION = "2022-11-28";
const APK_NAME = "app-debug.apk";
const UPDATE_INFO_NAME = "update-info.json";

function responseHeaders(contentType?: string): Headers {
  const headers = new Headers({
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "Accept, Content-Type",
    "X-Content-Type-Options": "nosniff",
    "Cache-Control": "no-store",
  });
  if (contentType) headers.set("Content-Type", contentType);
  return headers;
}

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: responseHeaders("application/json; charset=utf-8"),
  });
}

function githubHeaders(token: string, accept = "application/vnd.github+json"): HeadersInit {
  return {
    Authorization: `Bearer ${token}`,
    Accept: accept,
    "X-GitHub-Api-Version": GITHUB_API_VERSION,
    "User-Agent": "SainikSchool-AI-Update-Gateway",
  };
}

function repositoryName(env: Env): string {
  const repository = env.GITHUB_REPOSITORY || "SainikSchool-ai/SainikSchool-panel";
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository)) {
    throw new Error("Invalid GITHUB_REPOSITORY setting.");
  }
  return repository;
}

async function githubJson<T>(url: string, env: Env): Promise<T> {
  const response = await fetch(url, { headers: githubHeaders(env.GITHUB_RELEASES_TOKEN) });
  if (!response.ok) {
    console.error("GitHub API error", response.status, (await response.text()).slice(0, 300));
    throw new Error(`GitHub API returned HTTP ${response.status}.`);
  }
  return await response.json() as T;
}

async function latestRelease(env: Env): Promise<{
  release: GitHubRelease;
  apk: GitHubAsset;
  info: UpdateInfo;
}> {
  if (!env.GITHUB_RELEASES_TOKEN) throw new Error("GITHUB_RELEASES_TOKEN is not configured.");

  const repo = repositoryName(env);
  const release = await githubJson<GitHubRelease>(
    `https://api.github.com/repos/${repo}/releases/latest`, env,
  );
  const apk = release.assets?.find((asset) => asset.name === APK_NAME);
  const infoAsset = release.assets?.find((asset) => asset.name === UPDATE_INFO_NAME);
  if (!apk || !infoAsset) {
    throw new Error("Latest release must contain app-debug.apk and update-info.json.");
  }

  const infoResponse = await fetch(infoAsset.url, {
    headers: githubHeaders(env.GITHUB_RELEASES_TOKEN, "application/octet-stream"),
  });
  if (!infoResponse.ok) throw new Error(`Could not fetch update metadata (HTTP ${infoResponse.status}).`);
  const info = await infoResponse.json() as UpdateInfo;
  if (typeof info.versionName !== "string" || !/^\d+(\.\d+)*$/.test(info.versionName)
      || !Number.isSafeInteger(info.versionCode) || info.versionCode < 1
      || info.applicationId !== "com.sainikschool.ai") {
    throw new Error("update-info.json contains invalid app version metadata.");
  }
  return { release, apk, info };
}

async function handle(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: responseHeaders() });
  if (request.method !== "GET" && request.method !== "HEAD") {
    return jsonResponse({ error: "Method not allowed." }, 405);
  }

  if (url.pathname === "/health") {
    return jsonResponse({ ok: true, service: "sainikschool-updates" });
  }

  if (url.pathname === "/api/v1/update/latest") {
    try {
      const { release, info } = await latestRelease(env);
      return jsonResponse({
        versionName: info.versionName,
        versionCode: info.versionCode,
        applicationId: info.applicationId,
        tagName: release.tag_name,
        releaseUrl: release.html_url,
        apkUrl: `${url.origin}/api/v1/update/apk`,
      });
    } catch (error) {
      console.error("Latest update lookup failed", error);
      return jsonResponse({ error: "Could not retrieve the latest app release." }, 502);
    }
  }

  if (url.pathname === "/api/v1/update/apk") {
    try {
      const { apk } = await latestRelease(env);
      const repo = repositoryName(env);
      const assetUrl = `https://api.github.com/repos/${repo}/releases/assets/${apk.id}`;
      const upstream = await fetch(assetUrl, {
        headers: githubHeaders(env.GITHUB_RELEASES_TOKEN, "application/octet-stream"),
      });
      if (!upstream.ok || !upstream.body) {
        console.error("GitHub APK download failed", upstream.status);
        return jsonResponse({ error: "Could not download APK from GitHub Releases." }, 502);
      }
      const headers = responseHeaders("application/vnd.android.package-archive");
      headers.set("Content-Disposition", 'attachment; filename="app-debug.apk"');
      const length = upstream.headers.get("Content-Length");
      if (length) headers.set("Content-Length", length);
      return new Response(request.method === "HEAD" ? null : upstream.body, { status: 200, headers });
    } catch (error) {
      console.error("APK proxy failed", error);
      return jsonResponse({ error: "Could not retrieve the latest APK." }, 502);
    }
  }

  return jsonResponse({ error: "Not found." }, 404);
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    try {
      return await handle(request, env);
    } catch (error) {
      console.error("Worker request failed", error);
      return jsonResponse({ error: "Internal server error." }, 500);
    }
  },
};
