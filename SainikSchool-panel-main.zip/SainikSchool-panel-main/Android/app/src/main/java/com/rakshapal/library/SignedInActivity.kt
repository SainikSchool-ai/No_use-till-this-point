package com.sainikschool.ai

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class SignedInActivity : AppCompatActivity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val handler = Handler(Looper.getMainLooper())
    private var installPromptShown = false
    private val statusTicker = object : Runnable {
        override fun run() {
            refreshUpdateIndicator()
            maybePromptInstall()
            handler.postDelayed(this, 700)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signed_in)
        val username = intent.getStringExtra("username") ?: ""
        val role = intent.getStringExtra("role") ?: "user"
        val emailConnected = intent.getBooleanExtra("email_connected", false)
        findViewById<TextView>(R.id.tvSignedInUser).text = username
        findViewById<TextView>(R.id.tvRole).text = "Account role: ${role.replaceFirstChar { it.uppercase() }}"
        findViewById<TextView>(R.id.tvEmailNotice).visibility =
            if (role == "owner" || emailConnected) View.GONE else View.VISIBLE

        schedulePeriodicCheck(this)
        checkForUpdateOnOpen()
        // MainActivity is finishing during this transition. Start this Activity's watcher
        // just after that teardown so the previous Activity cannot stop the new watcher.
        handler.postDelayed({ if (!isFinishing) startApkFileWatcher(this) }, 650)
        findViewById<ImageButton>(R.id.btnUpdateStatus).setOnClickListener { showUpdateStatus() }
        handler.post(statusTicker)

        findViewById<Button>(R.id.btnSignOut).setOnClickListener {
            it.isEnabled = false
            scope.launch {
                try { SainikSchoolApi.logout(this@SignedInActivity) }
                catch (_: Exception) { /* Local session is cleared even if the network is unavailable. */ }
                startActivity(Intent(this@SignedInActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
                finish()
            }
        }
    }


    private fun checkForUpdateOnOpen() {
        scope.launch {
            val prefs = getSharedPreferences(UpdateConfig.PREFS, MODE_PRIVATE)
            if (prefs.getBoolean(UpdateConfig.KEY_READY, false) && getApkFile(this@SignedInActivity).exists()) {
                maybePromptInstall()
                return@launch
            }
            if (prefs.getBoolean(UpdateConfig.KEY_DOWNLOADING, false)) return@launch
            val latest = fetchLatestVersionName() ?: return@launch
            val current = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "0" }
                catch (_: Exception) { return@launch }
            if (!isNewer(latest, current)) {
                prefs.edit().putBoolean(UpdateConfig.KEY_AVAILABLE, false)
                    .putBoolean(UpdateConfig.KEY_DOWNLOADING, false).putInt(UpdateConfig.KEY_PROGRESS, 0).apply()
                return@launch
            }
            prefs.edit().putBoolean(UpdateConfig.KEY_AVAILABLE, true).putString(UpdateConfig.KEY_VERSION, latest).apply()
            val downloaded = downloadApkSilently(this@SignedInActivity)
            if (downloaded) {
                prefs.edit().putBoolean(UpdateConfig.KEY_READY, true)
                    .putBoolean(UpdateConfig.KEY_AVAILABLE, true).putString(UpdateConfig.KEY_VERSION, latest).apply()
                maybePromptInstall()
            }
        }
    }

    private fun refreshUpdateIndicator() {
        val prefs = getSharedPreferences(UpdateConfig.PREFS, MODE_PRIVATE)
        val downloading = prefs.getBoolean(UpdateConfig.KEY_DOWNLOADING, false)
        val ready = prefs.getBoolean(UpdateConfig.KEY_READY, false)
        val available = prefs.getBoolean(UpdateConfig.KEY_AVAILABLE, false)
        val progress = prefs.getInt(UpdateConfig.KEY_PROGRESS, 0)
        val badge = findViewById<View>(R.id.tvUpdateBadge)
        val label = findViewById<TextView>(R.id.tvUpdateProgress)
        val icon = findViewById<ImageButton>(R.id.btnUpdateStatus)
        badge.visibility = if (downloading || ready || available) View.VISIBLE else View.GONE
        when {
            downloading -> { label.text = if (progress > 0) "Downloading $progress%" else "Downloading…"; label.visibility = View.VISIBLE; icon.imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFB74D.toInt()) }
            ready -> { label.text = "Ready to install"; label.visibility = View.VISIBLE; icon.imageTintList = android.content.res.ColorStateList.valueOf(0xFF5CD291.toInt()) }
            available -> { label.text = "Update available"; label.visibility = View.VISIBLE; icon.imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFB74D.toInt()) }
            else -> { label.visibility = View.GONE; icon.imageTintList = android.content.res.ColorStateList.valueOf(0xFFB7C8DD.toInt()) }
        }
    }

    private fun showUpdateStatus() {
        val prefs = getSharedPreferences(UpdateConfig.PREFS, MODE_PRIVATE)
        val version = prefs.getString(UpdateConfig.KEY_VERSION, "") ?: ""
        val downloading = prefs.getBoolean(UpdateConfig.KEY_DOWNLOADING, false)
        val ready = prefs.getBoolean(UpdateConfig.KEY_READY, false)
        val available = prefs.getBoolean(UpdateConfig.KEY_AVAILABLE, false)
        val progress = prefs.getInt(UpdateConfig.KEY_PROGRESS, 0)
        val message = when {
            downloading -> "Downloading version $version automatically…\nProgress: $progress%"
            ready -> "Version $version is downloaded and ready to install."
            available -> "Version $version was found. The automatic download will continue when network is available."
            else -> "Your app is up to date."
        }
        AlertDialog.Builder(this).setTitle("App updates").setMessage(message)
            .setPositiveButton(if (ready) "Install" else "OK") { _, _ -> if (ready) promptInstall(this, version) }.show()
    }

    private fun maybePromptInstall() {
        val prefs = getSharedPreferences(UpdateConfig.PREFS, MODE_PRIVATE)
        if (installPromptShown || !prefs.getBoolean(UpdateConfig.KEY_READY, false)) return
        if (!getApkFile(this).exists()) return
        installPromptShown = true
        promptInstall(this, prefs.getString(UpdateConfig.KEY_VERSION, "") ?: "")
    }

    override fun onResume() {
        super.onResume()
        refreshUpdateIndicator()
        installPromptShown = false
        maybePromptInstall()
    }

    override fun onDestroy() {
        handler.removeCallbacks(statusTicker)
        handler.removeCallbacksAndMessages(null)
        stopApkFileWatcher()
        scope.cancel()
        super.onDestroy()
    }
}
