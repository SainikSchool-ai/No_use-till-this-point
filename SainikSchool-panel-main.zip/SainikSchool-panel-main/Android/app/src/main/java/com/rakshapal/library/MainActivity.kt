package com.sainikschool.ai

import android.animation.AnimatorInflater
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaDrm
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.cardview.widget.CardView
import kotlinx.coroutines.*
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private val LIBRARY_URL             = "https://rakshapal-singh-library-ded2e.web.app"
    private val WIDEVINE_UUID           = UUID(-0x121074568629b532L, -0x5c37d8232ae2de13L)
    private val updateScope             = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var floatAnimator: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Keep the existing automatic-update system active and unchanged.
        schedulePeriodicCheck(this)
        startApkFileWatcher(this)
        checkForUpdateOnOpen()

        window.statusBarColor = android.graphics.Color.rgb(13, 25, 45)
        window.navigationBarColor = android.graphics.Color.rgb(13, 25, 45)

        runEntranceAnimations()

        findViewById<Button>(R.id.btnLogin).setOnClickListener { view ->
            animateButtonPress(view) {
                val username = findViewById<android.widget.EditText>(R.id.usernameInput)
                    .text.toString().trim()
                val password = findViewById<android.widget.EditText>(R.id.passwordInput)
                    .text.toString()

                when {
                    username.isEmpty() -> findViewById<android.widget.EditText>(R.id.usernameInput).error = "Enter your username or email"
                    password.isEmpty() -> findViewById<android.widget.EditText>(R.id.passwordInput).error = "Enter your password"
                    else -> Toast.makeText(this, "Login backend will be connected in the next milestone.", Toast.LENGTH_LONG).show()
                }
            }
        }

        findViewById<Button>(R.id.btnGoogleRegister).setOnClickListener { view ->
            animateButtonPress(view) {
                Toast.makeText(this, "Google registration will be connected in the next milestone.", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<TextView>(R.id.createAccountLink).setOnClickListener {
            Toast.makeText(this, "Registration screen is the next milestone.", Toast.LENGTH_SHORT).show()
        }

        findViewById<TextView>(R.id.forgotPasswordLink).setOnClickListener {
            Toast.makeText(this, "Password recovery will be added with the Cloudflare backend.", Toast.LENGTH_LONG).show()
        }
    }

    private fun runEntranceAnimations() {
        val card = findViewById<View>(R.id.loginCard)
        val brand = findViewById<View>(R.id.brandHeader)
        card.alpha = 0f
        card.translationY = 28f
        brand.alpha = 0f
        brand.translationY = 12f
        card.animate().alpha(1f).translationY(0f).setDuration(420).start()
        brand.animate().alpha(1f).translationY(0f).setDuration(500).start()
    }

    private fun animateButtonPress(view: View, action: () -> Unit) {
        view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(75).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(90).withEndAction { action() }.start()
        }.start()
    }

    // ── Chrome Custom Tab ──────────────────────────────────────────────────

    private fun openInCustomTab(url: String) {
        val cti = CustomTabsIntent.Builder()
            .setShowTitle(true)
            .setShareState(CustomTabsIntent.SHARE_STATE_OFF)
            .build()
        cti.intent.apply {
            setPackage("com.android.chrome")
            addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        }
        try {
            cti.launchUrl(this, Uri.parse(url))
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY))
        }
    }

    // FIX (e): bring MainActivity to front so dialog shows OVER the CCT
    private fun closeCctAndBringToFront() {
        try {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
        } catch (e: Exception) { Log.e("CCT", "reorder failed: ${e.message}") }

        try {
            startActivity(Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            Handler(Looper.getMainLooper()).postDelayed({
                packageManager.getLaunchIntentForPackage(packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }?.also { startActivity(it) }
            }, 300)
        } catch (e: Exception) { Log.e("CCT", "home+reopen failed: ${e.message}") }
    }

    // ── FIX (c) & (f): Check for pending update on EVERY open ────────────
    // KEY_READY stays true across app restarts until user taps "Install Now".
    // So even after closing and reopening the app the dialog reappears.

    private fun checkForUpdateOnOpen() {
        updateScope.launch {
            val prefs = getSharedPreferences(UpdateConfig.PREFS, Context.MODE_PRIVATE)

            // Case 1: update already downloaded and waiting
            if (prefs.getBoolean(UpdateConfig.KEY_READY, false)) {
                val apkFile = getApkFile(this@MainActivity)
                if (apkFile.exists()) {
                    val savedVersion = prefs.getString(UpdateConfig.KEY_VERSION, "") ?: ""
                    // FIX (e): bring this Activity to front before showing dialog
                    closeCctAndBringToFront()
                    delay(700)
                    promptInstall(this@MainActivity, savedVersion)
                    return@launch
                } else {
                    // APK was cleared (e.g. uninstall cleaned storage) — reset flag
                    prefs.edit().remove(UpdateConfig.KEY_READY).remove(UpdateConfig.KEY_VERSION).apply()
                }
            }

            // Case 2: no pending APK — check GitHub for new version
            if (!isNetworkAvailable()) return@launch
            val latestVersion = fetchLatestVersionName() ?: return@launch
            val currentVersion = try {
                packageManager.getPackageInfo(packageName, 0).versionName
            } catch (e: PackageManager.NameNotFoundException) { return@launch }
            if (!isNewer(latestVersion, currentVersion)) return@launch

            Log.d(UpdateConfig.TAG, "Newer version $latestVersion found — downloading…")
            val success = downloadApkSilently(this@MainActivity)
            if (success) {
                // Mark as ready, same as the background UpdateWorker does,
                // so the dialog persists across restarts even if user
                // closes the app before tapping Install.
                prefs.edit()
                    .putBoolean(UpdateConfig.KEY_READY, true)
                    .putString(UpdateConfig.KEY_VERSION, latestVersion)
                    .apply()

                // FIX (e): bring to front so dialog is visible
                closeCctAndBringToFront()
                delay(700)
                promptInstall(this@MainActivity, latestVersion)
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        return cm.activeNetworkInfo?.isConnected == true
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onDestroy() {
        super.onDestroy()
        floatAnimator?.cancel()
        updateScope.cancel()
        stopApkFileWatcher()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleDeepLink(intent)
    }

    @Deprecated("Overridden to disable back navigation")
    override fun onBackPressed() { /* disabled */ }

    // ── Deep link handler ──────────────────────────────────────────────────

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun handleDeepLink(intent: Intent) {
        val data: Uri = intent.data ?: return
        if (data.scheme != "mylibraryapp") return
        when (data.host) {
            "wifi" -> {
                val ssid        = data.getQueryParameter("ssid")              ?: ""
                val pass        = data.getQueryParameter("pass")              ?: ""
                val ssid2       = data.getQueryParameter("ssid2")             ?: ""
                val pass2       = data.getQueryParameter("pass2")             ?: ""
                val survivalStr = data.getQueryParameter("usersurvivaltime")  ?: "0"
                val name        = data.getQueryParameter("name")              ?: ""
                val father      = data.getQueryParameter("father")            ?: ""
                val phone       = data.getQueryParameter("phone")             ?: ""
                val address     = data.getQueryParameter("address")           ?: ""

                val survivalDays = survivalStr.toDoubleOrNull() ?: 0.0

                UserDataManager.saveAll(
                    context      = this,
                    name         = name,
                    father       = father,
                    phone        = phone,
                    address      = address,
                    ssid         = ssid,
                    pass         = pass,
                    ssid2        = ssid2,
                    pass2        = pass2,
                    survivalDays = survivalDays
                )

                // NEW: calculate the exact expiry date/time from survivalDays
                // and schedule the 3-shot expiry alarms (-3h / exact / +3h)
                // instead of relying on 15-min polling.
                calculateAndScheduleExpiry(
                    context               = this,
                    survivalDays          = survivalDays,
                    deepLinkFiredAtMillis = System.currentTimeMillis()
                )

                // REMOVED: no longer auto-creates a Wi-Fi suggestion here.
                // The suggestion is now made ONLY when the user manually taps
                // a "Connect to <ssid>" button on the Offline Dashboard page.

                // Open Offline Dashboard immediately after saving data
                startActivity(Intent(this, OfflineDashboardActivity::class.java))
            }
            "forgetwifi" -> forgetLibraryWifi()
            "getdeviceid" -> handleGetDeviceId(data.getQueryParameter("callback"))
        }
    }

    // ── MediaDrm ──────────────────────────────────────────────────────────

    private fun handleGetDeviceId(callbackUrl: String?) {
        try {
            val mediaDrm      = MediaDrm(WIDEVINE_UUID)
            val deviceIdBytes = mediaDrm.getPropertyByteArray(MediaDrm.PROPERTY_DEVICE_UNIQUE_ID)
            mediaDrm.close()
            val deviceIdHex = deviceIdBytes.joinToString("") { "%02x".format(it) }
            val returnUrl = if (!callbackUrl.isNullOrBlank())
                Uri.parse(callbackUrl).buildUpon().appendQueryParameter("drm_id", deviceIdHex).build().toString()
            else LIBRARY_URL
            openInCustomTab(returnUrl)
        } catch (e: Exception) {
            Log.e("MediaDrm", "Failed: ${e.message}")
            Toast.makeText(this, "Device verification failed. Please try again.", Toast.LENGTH_LONG).show()
            val errorUrl = if (!callbackUrl.isNullOrBlank())
                Uri.parse(callbackUrl).buildUpon().appendQueryParameter("drm_error", "extraction_failed").build().toString()
            else LIBRARY_URL
            openInCustomTab(errorUrl)
        }
    }

    // ── Wi-Fi connect logic moved entirely to OfflineDashboardActivity.
    //    MainActivity no longer creates Wi-Fi suggestions on its own —
    //    only the user's explicit "Connect to <ssid>" tap does that.


    @RequiresApi(Build.VERSION_CODES.Q)
    private fun forgetLibraryWifi() {
        UserDataManager.deleteAll(this)
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.removeNetworkSuggestions(wm.networkSuggestions)
        Toast.makeText(this, "Disconnected from Library Wi-Fi.\nMembership ended.", Toast.LENGTH_LONG).show()
    }
}
