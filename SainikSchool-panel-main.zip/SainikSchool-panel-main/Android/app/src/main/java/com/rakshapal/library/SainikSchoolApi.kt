package com.sainikschool.ai

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Set this to the exact URL Cloudflare assigns to the sainikschool-api Worker. */
object SainikSchoolApiConfig {
    const val BASE_URL = "https://sainikschool-api.minecraft-server-panel.workers.dev"
}

data class SignedInUser(
    val id: String,
    val username: String,
    val email: String?,
    val role: String,
    val emailConnected: Boolean
)

/** Stores the bearer token encrypted with an Android Keystore AES-GCM key. */
private object SessionVault {
    private const val PREFS = "sainikschool_secure_session"
    private const val TOKEN = "access_token_encrypted"
    private const val KEY_ALIAS = "sainikschool_ai_session_key"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun save(context: android.content.Context, token: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        val encoded = Base64.encodeToString(packed, Base64.NO_WRAP)
        context.getSharedPreferences(PREFS, 0).edit().putString(TOKEN, encoded).apply()
    }

    fun read(context: android.content.Context): String? {
        val encoded = context.getSharedPreferences(PREFS, 0).getString(TOKEN, null) ?: return null
        return try {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            if (packed.size <= 12) return null
            val iv = packed.copyOfRange(0, 12)
            val ciphertext = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            clear(context)
            null
        }
    }

    fun clear(context: android.content.Context) {
        context.getSharedPreferences(PREFS, 0).edit().remove(TOKEN).apply()
    }
}

object SainikSchoolApi {
    suspend fun login(context: android.content.Context, identifier: String, password: String): SignedInUser =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("identifier", identifier).put("password", password)
            val response = request("POST", "/api/v1/auth/login", body, null)
            val token = response.optString("accessToken")
            if (token.isBlank()) throw IllegalStateException("The API did not return an Android session token.")
            SessionVault.save(context, token)
            parseUser(response.getJSONObject("user"))
        }

    suspend fun currentUser(context: android.content.Context): SignedInUser? = withContext(Dispatchers.IO) {
        val token = SessionVault.read(context) ?: return@withContext null
        try {
            val response = request("GET", "/api/v1/auth/me", null, token)
            parseUser(response.getJSONObject("user"))
        } catch (e: ApiHttpException) {
            if (e.statusCode == 401) SessionVault.clear(context)
            null
        } catch (_: Exception) {
            // Keep the saved token when the network is temporarily unavailable.
            null
        }
    }

    suspend fun logout(context: android.content.Context) = withContext(Dispatchers.IO) {
        val token = SessionVault.read(context)
        try {
            if (token != null) request("POST", "/api/v1/auth/logout", JSONObject(), token)
        } finally {
            SessionVault.clear(context)
        }
    }

    fun hasSavedSession(context: android.content.Context): Boolean = SessionVault.read(context) != null

    private fun parseUser(json: JSONObject) = SignedInUser(
        id = json.optString("id"),
        username = json.optString("username"),
        email = if (json.isNull("email")) null else json.optString("email"),
        role = json.optString("role", "user"),
        emailConnected = json.optBoolean("emailConnected", false)
    )

    private fun request(method: String, path: String, body: JSONObject?, token: String?): JSONObject {
        val base = SainikSchoolApiConfig.BASE_URL.trimEnd('/')
        require(base.startsWith("https://") && !base.contains("REPLACE")) {
            "Set SainikSchoolApiConfig.BASE_URL to your deployed HTTPS Cloudflare Worker URL."
        }
        val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Client-Platform", "android")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299) throw ApiHttpException(code, json.optString("error", "Request failed ($code)."))
            return json
        } finally {
            connection.disconnect()
        }
    }
}

class ApiHttpException(val statusCode: Int, message: String) : Exception(message)
