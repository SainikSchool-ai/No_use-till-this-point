const cfg = window.SAINIKSCHOOL_CONFIG || {};
const apiBase = (cfg.apiBaseUrl || "").replace(/\/$/, "");
const loginCard = document.getElementById("login-card");
const dashboardCard = document.getElementById("dashboard-card");
const form = document.getElementById("login-form");
const message = document.getElementById("message");
const button = document.getElementById("login-button");

async function api(path, options = {}) {
  if (!apiBase || apiBase.includes("REPLACE-WITH-YOUR-SUBDOMAIN")) {
    throw new Error("The API address has not been configured yet.");
  }
  const response = await fetch(apiBase + path, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed. Please try again.");
  return data;
}
function showDashboard(user) {
  loginCard.classList.add("hidden");
  dashboardCard.classList.remove("hidden");
  document.getElementById("welcome").textContent = `Welcome, ${user.username}`;
  document.getElementById("account-summary").textContent = `Role: ${user.role}`;
  document.getElementById("email-notice").classList.toggle("hidden", user.role === "owner" || user.emailConnected);
}
async function checkSession() {
  try {
    const data = await api("/api/v1/auth/me");
    showDashboard(data.user);
  } catch (_) { /* No active session: keep login screen visible. */ }
}
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";
  button.disabled = true;
  button.textContent = "Signing in…";
  try {
    const data = await api("/api/v1/auth/login", {
      method: "POST",
      body: JSON.stringify({
        identifier: document.getElementById("identifier").value.trim(),
        password: document.getElementById("password").value
      })
    });
    showDashboard(data.user);
  } catch (error) {
    message.textContent = error.message;
  } finally {
    button.disabled = false;
    button.textContent = "Sign in";
  }
});
document.getElementById("logout-button").addEventListener("click", async () => {
  try { await api("/api/v1/auth/logout", { method: "POST", body: "{}" }); }
  finally {
    dashboardCard.classList.add("hidden");
    loginCard.classList.remove("hidden");
    form.reset();
  }
});
checkSession();
