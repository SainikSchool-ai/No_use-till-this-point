// Set this to the deployed API Worker origin before publishing the website.
window.SAINIKSCHOOL_CONFIG = {
  apiBaseUrl: "https://sainikschool-api.REPLACE-WITH-YOUR-SUBDOMAIN.workers.dev"
};
